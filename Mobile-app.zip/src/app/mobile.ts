export interface Mobile {
    imeiNo:string;
    brand:string;
    model:string;
    price:number;
}
